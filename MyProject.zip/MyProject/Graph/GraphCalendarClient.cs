
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Graph;
using System.Linq;
using System.Net;
using TimeZoneConverter;

namespace DotNetCoreRazor_MSGraph.Graph
{
    public class GraphCalendarClient
    {
        private readonly ILogger<GraphCalendarClient> _logger = null;
        private readonly GraphServiceClient _graphServiceClient = null;

        public GraphCalendarClient(ILogger<GraphCalendarClient> logger, GraphServiceClient graphServiceClient)
        {
            
            _logger = logger;
            _graphServiceClient = graphServiceClient;
        }

        //Function to display all the events in Calendar 
        public async Task<IEnumerable<Event>> GetEvents(string userTimeZone)
        {
            _logger.LogInformation($"User timezone: {userTimeZone}");
         
            // Configure a calendar view for the current week
            var startOfWeek = DateTime.Now;
            var endOfWeek = startOfWeek.AddDays(7);
            var viewOptions = new List<QueryOption>
            {
                new QueryOption("startDateTime", startOfWeek.ToString("o")),
                new QueryOption("endDateTime", endOfWeek.ToString("o"))
            };
            try
            {
                // Use GraphServiceClient to call Me.CalendarView
                var calendarEvents = await _graphServiceClient
                    .Me
                    .CalendarView
                    .Request(viewOptions)
                    .Header("Prefer", $"outlook.timezone=\"{userTimeZone}\"")
                    .Select(evt => new
                    {
                        evt.Subject,
                        evt.Organizer,
                        evt.Start,
                        evt.End
                    })
                    .OrderBy("start/DateTime")
                    .GetAsync();

                return calendarEvents;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error calling the Graph /me/calendaview: {ex.Message}");
                throw;
            }
            
        }

        //Function to display only the day's task
        public async Task<IEnumerable<Event>> GetEventsForTheDay(string userTimeZone)
        {
            _logger.LogInformation($"User timezone: {userTimeZone}");
            //To Fetch the current time and end of day
            var currentTime=DateTimeOffset.UtcNow;
            var endOfDay=new DateTimeOffset(currentTime.Year,currentTime.Month,currentTime.Day,23,59,59,TimeSpan.Zero);

            //To Define start and end times of the query
            var startOfDay = new DateTimeOffset(currentTime.Year, currentTime.Month, currentTime.Day, 0, 0, 0, TimeSpan.Zero);
            var viewOptions = new List<QueryOption>
            {
                new QueryOption("startDateTime", startOfDay.ToString("s")),
                new QueryOption("endDateTime", endOfDay.ToString("s"))
            };
            try
            {
                // Use GraphServiceClient to call Me.CalendarView
                var calendarEvents = await _graphServiceClient
                    .Me
                    .CalendarView
                    .Request(viewOptions)
                    .Header("Prefer", $"outlook.timezone=\"{userTimeZone}\"")
                    .Select(evt => new
                    {
                        evt.Subject,
                        evt.Organizer,
                        evt.Start,
                        evt.End
                    })
                    .OrderBy("start/DateTime")
                    .GetAsync();

                return calendarEvents;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error calling the Graph /me/calendaview: {ex.Message}");
                throw;
            }

        }

        // Used for timezone settings related to calendar
        public async Task<MailboxSettings> GetUserMailboxSettings()
        {
            try
            {
                var currentUser = await _graphServiceClient
                    .Me
                    .Request()
                    .Select(u => new
                    {
                        u.MailboxSettings
                    })
                    .GetAsync();

                return currentUser.MailboxSettings;
            }
            catch (Exception ex)
            {
                _logger.LogError($"/me Error: {ex.Message}");
                throw;
            }
        }

        private static DateTime GetUtcStartOfWeekInTimeZone(DateTime today, string timeZoneId)
        {
            TimeZoneInfo userTimeZone = TZConvert.GetTimeZoneInfo(timeZoneId);

            // Assumes Sunday as first day of week
            int diff = System.DayOfWeek.Sunday - today.DayOfWeek;

            // create date as unspecified kind
            var unspecifiedStart = DateTime.SpecifyKind(today.AddDays(diff), DateTimeKind.Unspecified);

            // convert to UTC
            return TimeZoneInfo.ConvertTimeToUtc(unspecifiedStart, userTimeZone);
        }

    }
}